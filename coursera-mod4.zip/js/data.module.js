

(function(){
	
	angular.module("data", []);
	
})();