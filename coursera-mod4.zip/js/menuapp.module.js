

(function(){
	
	angular.module('MenuApp', ['data', 'ui.router']);
	
})();